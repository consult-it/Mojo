# -*- coding: utf-8 -*-

from odoo import models, fields, api

class PosZimra(models.Model):
    _name = "pos_zimra.pos_zimra"
    _description = "Record of Zimra submissions"

    pos_reference = fields.Char(string="Pos Reference")
    zimra_hash = fields.Char(string="Zimra Hash")

class AccountMove(models.Model):
    _inherit = "account.move"
    
    zimra_hash = fields.Char(string="Zimra Hash", compute='_compute_zimra')

    @api.model
    def _compute_zimra(self):
        
        line = self.env['pos.order'].search([("account_move", '=', self.id)])

        if(line.id != None):

            hash_ = self.env['pos_zimra.pos_zimra'].search([("pos_reference", "=", line.pos_reference)])

            if(hash_.id != None):
                self.zimra_hash = f"{hash_.zimra_hash}"

            else:
                self.zimra_hash = "None"
        else:
            self.zimra_hash = "None"




    
