odoo.define('pos_zimra.submit', (require) => {
    "use strict"

    const PaymentScreen = require('point_of_sale.PaymentScreen')
    const Registries = require('point_of_sale.Registries')
    var rpc = require('web.rpc')
    
    const ZimraPaymentScreen = PaymentScreen =>
    class  extends PaymentScreen {
        constructor() {
            super(...arguments);
        }
        
        async validateOrder(isForceValidate) {

            if (await this._isOrderValid(isForceValidate)) {
                for (let line of this.paymentLines) {
                    if (!line.is_done()) this.currentOrder.remove_paymentline(line);
                }

                let zimra_hash = await this._processFunction()

                let order_paymentline = this.currentOrder.selected_paymentline;

                order_paymentline.set_receipt_info('<br/>Zimra: ' + zimra_hash + '<br/>')

                await this._finalizeValidation();
            }
        }

        async _handle_odoo_connection_failure (data) {
            // let line = this.currentOrder.selected_paymentline;
            // if (line) {
            //     line.set_payment_status('retry');
            // }
            
            // await this.showPopup('ErrorPopup', {
            //     title: 'Falied to submit zimra',
            //     body: 'Falied to submit zimra',
            // });
            // return Promise.reject(data); // prevent subsequent onFullFilled's from being called

            // console.log("Error")

            return false
        }

       
        async _processFunction() {
            let order = this.currentOrder;

            let arrdata = []

            order.orderlines.models.forEach(element => {

                let value = {
                    "product_name": element.product.display_name,
                    "code": element.product.default_code,
                    "qty": element.quantity,
                    "price": element.price
                }

                if (element.product.taxes_id.length == 0) {
                    value["amount"] = element.price
                    value["tax"] = 0
                    value["tax_r"] = 0
                } else {
                    value["amount"] = element.price + (element.price * element.pos.taxes_by_id[element.product.taxes_id[0]]['amount']) / 100.0
                    value["tax"] = element.price * element.pos.taxes_by_id[element.product.taxes_id[0]]['amount'] / 100.0
                    value["tax_r"] = element.pos.taxes_by_id[element.product.taxes_id[0]]['amount'] / 100.0

                }

                arrdata.push(value)
            });

            let bodyData = {
                "payment": {
                    "currency": "ZWL",
                    "amount": order.get_total_with_tax(),
                    "amount_tax": order.get_total_tax(),
                    "order_id": order.name
                },
                "products": arrdata
            }

            return rpc.query({
                model: 'res.config.settings',
                method: 'handle_latest_request',
                args: [JSON.stringify(bodyData)],
            }, {
                
                timeout: 5000,
                shadow: true,
            }).catch(this._handle_odoo_connection_failure.bind(this));

        }

   
    }

    ZimraPaymentScreen.template = 'pos_zimra.PaymentScreen';
    Registries.Component.extend(PaymentScreen, ZimraPaymentScreen);

    return ZimraPaymentScreen;

})