# -*- coding: utf-8 -*-
# from odoo import http


# class PosZimra(http.Controller):
#     @http.route('/pos_zimra/pos_zimra/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pos_zimra/pos_zimra/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('pos_zimra.listing', {
#             'root': '/pos_zimra/pos_zimra',
#             'objects': http.request.env['pos_zimra.pos_zimra'].search([]),
#         })

#     @http.route('/pos_zimra/pos_zimra/objects/<model("pos_zimra.pos_zimra"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pos_zimra.object', {
#             'object': obj
#         })
