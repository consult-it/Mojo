
# -*- coding: utf-8 -*-

from odoo import models, fields, api
import requests


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    url = fields.Char(string='url')

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()

        self.env['ir.config_parameter'].set_param('pos_zimra.url', self.url)

        return res

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()

        url = self.env['ir.config_parameter'].sudo().get_param('pos_zimra.url')

        res.update(
            url=url
        )

        return res

    @api.model
    def handle_latest_request(self, data_param):
        import json

        try:
            url = self.env['ir.config_parameter'].sudo().get_param('pos_zimra.url')

            headers = {
                'Content-type': 'application/json'
            }

            data = json.loads(data_param)
            response = requests.post(url=url, json=data, headers=headers)
            
            if response.status_code == 200:
                _data = json.loads(response.content)

                code = _data['code']

                vals = {"pos_reference": data["payment"]["order_id"], "zimra_hash": code}
                
                record = self.env['pos_zimra.pos_zimra'].create(vals)

                return code

            return False

        except Exception as e:

            return False
